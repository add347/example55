import React from 'react'

const Fonts = () => (
  <link
    href="https://fonts.googleapis.com/css?family=IBM+Plex+Mono:300,400,500,700|IBM+Plex+Sans:300,400,500,700|IBM+Plex+Serif:300,400,700|Roboto:300,400,700"
    rel="stylesheet"
  />
)

export default Fonts
