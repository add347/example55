export default function localStorageAvailable() {
  return true
}
