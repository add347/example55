export const SET_NETWORK = 'network/SET_NETWORK'

export const setNetwork = network => ({
  type: SET_NETWORK,
  network,
})
