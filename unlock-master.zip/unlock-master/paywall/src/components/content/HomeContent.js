import React from 'react'

import LandingPage from '../LandingPage'

export default function HomeContent() {
  return <LandingPage />
}
