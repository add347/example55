import React from 'react'
import DemoContent from '../components/content/DemoContent'

const Demo = () => <DemoContent />

export default Demo
