import React from 'react'
import PaywallContent from '../components/content/PaywallContent'

export default function NextPaywall() {
  return <PaywallContent />
}
