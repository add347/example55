import React from 'react'

import HomeContent from '../components/content/HomeContent'

export default function Home() {
  return <HomeContent />
}
