import React from 'react'
import { storiesOf } from '@storybook/react'
import { UnlockedFlag } from '../../components/lock/UnlockFlag'

const key = {
  address: '0xab7c74abc0c4d48d1bdad5dcb26153fc87eeeeee',
  lock: '0xab7c74abc0c4d48d1bdad5dcb26153fc8780f83e',
  expiration: new Date('December 31, 3000 12:00:00').getTime() / 1000,
}

storiesOf('UnlockedFlag', module).add('the unlocked flag', () => {
  return <UnlockedFlag keys={[key]} expiration="April 5, 2019" />
})
