declare module '@unlock-protocol/unlock-js'
