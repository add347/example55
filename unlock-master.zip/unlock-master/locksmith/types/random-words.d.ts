export = index;
declare function index(options: any): any;
declare namespace index {
    const wordList: string[];
}
