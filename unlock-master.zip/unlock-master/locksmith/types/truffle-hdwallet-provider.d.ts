export = index;
declare class index {
    constructor(t: any?, e: any?, r: any?, a: any?, v: any?, g: any?);
    wallets: any;
    addresses: any;
    hdwallet: any;
    wallet_hdpath: any;
    engine: any;
    getAddress(t: any): any;
    getAddresses(): any;
    send(...args: any[]): any;
    sendAsync(...args: any[]): void;
}
