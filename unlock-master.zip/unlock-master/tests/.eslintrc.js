module.exports = {
  extends: ['../.eslintrc.js'],
  globals: {
    page: true,
    browser: true,
    context: true,
    jestPuppeteer: true,
  },
}
