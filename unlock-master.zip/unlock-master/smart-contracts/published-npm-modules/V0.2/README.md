# Unlock ABI v0.2

This npm module includes the ABI for the smart contracts Unlock.sol and PublicLock.sol for v0.2
The smart contracts have been compiled as of commit 32dd70fc.
