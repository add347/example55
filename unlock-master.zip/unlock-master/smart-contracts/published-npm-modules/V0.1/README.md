# Unlock ABI v0

This npm module includes the ABI for the smart contracts Unlock.sol and PublicLock.sol for v0.
The smart contracts have been compiled as of commit d2a3cc65.

This module is meant to be used by applications which want to interract with Unlock's smart contracts as of v0.
